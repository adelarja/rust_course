-- Your SQL goes here
CREATE TABLE posts (
    id INTEGER PdisRIMARY KEY AUTOINCREMENT,
    title VARCHAR,
    body VARCHAR
)
