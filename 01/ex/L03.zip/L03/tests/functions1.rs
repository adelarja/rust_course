// Don't mind this for now :)
// I AM NOT DONE

#[cfg(test)]
mod tests {

    #[test]
    fn call_function() {
        call_me();
    }

}