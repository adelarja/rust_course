#[cfg(test)]
mod tests {
    #[test]
    fn test_primitive_types1() {
        let is_morning = true;
        if is_morning {
            println!("Good morning!");
        }
    
        let // Finish the rest of this line like the example! Or make it be false!
        if is_evening {
            println!("Good evening!");
        }    
    }

}