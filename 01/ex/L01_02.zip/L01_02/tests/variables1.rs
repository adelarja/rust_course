#[cfg(test)]
mod tests {
    #[test]
    fn test_variables1() {
        x = 5;
        println!("x has the value {}", x);
    }
}