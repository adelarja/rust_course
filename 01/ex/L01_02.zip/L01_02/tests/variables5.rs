#[cfg(test)]
mod tests {
    #[test]
    fn test_variables5() {
        let number = "T-H-R-E-E"; // don't change this line
        println!("Spell a Number : {}", number);
        number = 3; // don't rename this variable
        println!("Number plus two is : {}", number + 2);
    }
}