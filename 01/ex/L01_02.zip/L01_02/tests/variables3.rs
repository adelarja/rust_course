#[cfg(test)]
mod tests {
    #[test]
    fn test_variables3() {
        let x: i32;
        println!("Number {}", x);
    }
}