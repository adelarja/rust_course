#[cfg(test)]
mod tests {
    #[test]
    fn test_variables2() {
        let x;
        if x == 10 {
            println!("x is ten!");
        } else {
            println!("x is not ten!");
        }
    }
}