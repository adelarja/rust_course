#[cfg(test)]
mod tests {
    #[test]
    fn test_variables4() {
        let x = 3;
        println!("Number {}", x);
        x = 5; // don't change this line
        println!("Number {}", x);
    }
}