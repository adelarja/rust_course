#[cfg(test)]
mod tests {
    #[test]
    fn test_variables6() {
        const NUMBER = 3;
        println!("Number {}", NUMBER);
    }
}